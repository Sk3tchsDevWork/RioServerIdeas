fx_version 'cerulean'
game 'gta5'

description 'Expanded Cartel System - ox_target, Skill Checks, and Laundering'

lua54 'yes'

shared_script '@ox_lib/init.lua'
client_scripts {
    'client/*.lua'
}
server_scripts {
    'server/*.lua'
}
